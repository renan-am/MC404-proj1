#include "montador.h"
#include <stdio.h>


/*
    ---- Voce deve implementar essa função para a Parte 2! ----
    Utilize os tokens da estrutura de tokens para montar seu código!
    Retorna:
        *  1 caso haja erro na montagem; (imprima o erro em stderr)
        *  0 caso não haja erro.
 */
int emitirMapaDeMemoria()
{
    /* printf("Voce deve implementar essa função para a Parte 2!");*/
    return 0;
}
